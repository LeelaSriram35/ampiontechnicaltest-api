package commonReusable;




import java.text.DecimalFormat;
import org.junit.Assert;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;
public class WeatherReport {

	public static void main(String args[]) {
		
			
		
	        Response response = given()
	                .contentType(ContentType.JSON)
	                .when()
	                .get("https://api.openweathermap.org/data/2.5/onecall?lat=-33.8699&lon=151.2025&units=metric&exclude=current,hourly,minutely&appid=2bd3f3e70e583e8aa39297edadc4fd54")
	                .then()
	                .extract().response();

	        Assert.assertEquals(200, response.statusCode());
	        
	        System.out.println("++++++++++++++" +response.asPrettyString());
	        
	        JsonPath jsonPath = JsonPath.from(response.asPrettyString());
	        String[] daytemp = jsonPath.getString("daily.temp.day").split(",");
	        
	        
	        System.out.println("++++++++++++++" +daytemp);
	        
	        for (int i = 0; i < daytemp.length; i++) {
				
	       	          	
	        	int tempconvert = 	Integer.parseInt(new DecimalFormat("#").format(Double.parseDouble(jsonPath.getString("daily.temp.day["+i+"]")))) ;
	        	
	        		        	
	        	 if (tempconvert >= 20) {
	 			
	        		 System.out.println("++++++++++++++" +jsonPath.getString("daily.temp.day["+i+"]"));
	        		 
	        		 System.out.println("++++++++++++++" +jsonPath.getString("daily.weather.main["+i+"]"));
	        		 
	 			}
	        	
			}
	        
	       
	        
	        //SerenityRest.get("https://api.openweathermap.org/data/2.5/onecall?lat=-33.8699&lon=151.2025&units=metric&exclude=current,hourly,minutely&appid=2bd3f3e70e583e8aa39297edadc4fd54");
	
		
	}
	
}

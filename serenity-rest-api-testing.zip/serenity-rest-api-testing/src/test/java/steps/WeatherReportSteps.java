/**----------------------------------------------------------------------
Class Name: WeatherReportSteps
Description: This java class will collate & organize all the steps that are to be implemented as part of 'Weather Forecast' and
captures test evidences without additional piece of code, Serenity default features supports this.
Date of Creation: 14/04/2020
Extends: NA
Implements: NA
Author: Leela, Sriram
-------------------------------------------------------------------------
Update Log: Newly designed and implemented for the technical test project
Date:14/04/2020 By:Leela, Sriram Details: No further updates
------------------------------------------------------------------------*/

package steps;

import java.util.Date;
import org.junit.Assert;
import commonReusable.Utilities;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

public class WeatherReportSteps {

	static Utilities util;
	public static int j=0;
	public static String response;
	
	 /**----------------------------------------------------------------------
    Method Name: getData()
    Description: This method is robust & reusable that can retrieve the required test data from xls file 
    Date of Creation: 14/04/2020
    Input Arguments: String getDataFor
    Return Parameters: void()
    Exception Used: e.getMessage()
    -------------------------------------------------------------------------
    Update Log: NA
    Date:NA By:NA Details: NA
    ------------------------------------------------------------------------*/  
	
	public String getData(String getDataFor) {

	return util.testData.get(getDataFor);

	}
	
	 /**----------------------------------------------------------------------
    Method Name: getResponse()
    Description: This method is reusable and robust that Retrive response for the given API
    Date of Creation: 14/04/2020
    Input Arguments: NA
    Return Parameters: void()
    Exception Used: e.getMessage()
    -------------------------------------------------------------------------
    Update Log: NA
    Date:NA By:NA Details: NA
    ------------------------------------------------------------------------*/  
	
	@Step("Retrive response for the given API")
	public void getResponse() {
		try {
			SerenityRest.get("https://api.openweathermap.org/data/2.5/onecall?lat=" + getData("lat") + "&lon="
					+ getData("lon") + "&units=" + getData("units") + "&exclude=" + getData("exclude") + "&appid="
					+ getData("appid") + "");

			  Assert.assertEquals(200, SerenityRest.lastResponse().statusCode());		  
			  	    
		      response =  SerenityRest.lastResponse().asString();
			
		} catch (Exception e) {
			e.getMessage();
		}
	}

	 /**----------------------------------------------------------------------
    Method Name: getResponse()
    Description: This method is used to capture the steps for reporting
    Date of Creation: 14/04/2020
    Input Arguments: NA
    Return Parameters: void()
    Exception Used: e.getMessage()
    -------------------------------------------------------------------------
    Update Log: NA
    Date:NA By:NA Details: NA
    ------------------------------------------------------------------------*/  
	
	@Step
	public void captureWeatherReportWithDegreesAndDescription(String daytemp, String weatherMain) {
		try {
			if (weatherMain.contentEquals("[Clear]")) {	 	   	 
		   		 System.out.println("++++++++++++++" +j++);		 		 
		   		 
				}	
				numberOfSunnyDaysPredicted(j);	
			
		} catch (Exception e) {
			e.getMessage();
		}
			
	}
	
	
	@Step
	public void numberOfSunnyDaysPredicted(int j) {		
		
	}
	
			

}
